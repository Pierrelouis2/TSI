clear variables, close all;
image =  im2double(imread('pieces.png'));
[h,w] = size(image);

I = Kmeans(image,2);
% figure(1);
% imshow(I);

H = imhist(image);
Hcum = cumsum(H);
% figure(2); hold on;
% bar(H);
% plot(Hcum);

Hnorm = H./(h*w);
% figure(3);
% bar(Hnorm);

egI = zeros(h,w);
for i = 1:h
    for j = 1:w
      egI(i,j) = Hcum(round(image(i,j)*256))./(h*w);
    end
end


H_eg = imhist(egI);
Hcum_eg = cumsum(H_eg);
% figure(4);
% subplot(211);imshow(egI);
% subplot(212);bar(H_eg);hold on;plot(Hcum_eg); 

I_egmeans = Kmeans(egI,2);
% figure(5);
% imshow(I_egmeans) ;

% GRANULOMETRIE
SE = strel('octagon',6);
I_ouv = imopen(I_egmeans,SE);
figure(6);
imshow(I_ouv);

%Methode 1
I_bord = imclearborder(I_ouv);
figure(7);
imshow(I_bord);

%Methode2
I_recons = imreconstruct( imerode(I_ouv,SE),I_ouv);
figure(8);
imshow(I_recons);


